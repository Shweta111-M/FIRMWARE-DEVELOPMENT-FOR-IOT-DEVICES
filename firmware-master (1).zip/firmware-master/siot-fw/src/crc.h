#include <inttypes.h>

bool CheckCRC(uint8_t* buf, int size);
