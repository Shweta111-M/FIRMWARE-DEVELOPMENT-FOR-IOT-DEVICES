

String formatU64Hex(uint64_t val);
