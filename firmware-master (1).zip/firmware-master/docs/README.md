+++
title = "Firmware"
weight = 3
sort_by = "weight"
insert_anchor_links = "right"
+++

The Simple IoT [firmware](https://github.com/simpleiot/firmware) currently
supports devices from [Particle.io](https://www.particle.io/)
